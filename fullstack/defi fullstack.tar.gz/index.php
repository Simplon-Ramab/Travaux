<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <script type="text/javascript" src="script.js">
  </script>
  <title> Evénements</title>
</head>
<body >
  <form class="" action="evenement.php" method="post">

     <h1>Evenements</h1>
       <h4 id = "titre">
       </h4>
       <h4 id = "debut">
       </h4>
     <h4 id="fin">
     </h4>
     <h4 id="createur">
     </h4>
     <button type="submit" name="button">Enregistrer</button><br>
  </form>




 </body>
</html>
</body>
</html>
